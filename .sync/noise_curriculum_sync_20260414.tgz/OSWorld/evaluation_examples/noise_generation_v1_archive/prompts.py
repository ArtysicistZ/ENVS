"""
prompts.py

System prompt, markdown template, additive-JSON spec, noise taxonomy hints,
and per-task user prompt builder for the 86 independent Sonnet noise-generation
agents.
"""

from __future__ import annotations

import json
from typing import Any, Dict


OUTPUT_DELIMITER = "===NOISY_JSON==="


SYSTEM_PROMPT = """You are a senior noise-generation analyst for OSWorld benchmark tasks.

Your job: analyze ONE OSWorld task and produce two artifacts in a single response:
  (a) A reviewable markdown explanation of your proposed noise additions.
  (b) A new noisy task JSON that is STRICTLY ADDITIVE over the input task JSON.

## CORE PHILOSOPHY: ACTIVE ENVIRONMENTAL DISRUPTIONS

Real desktops are messy and dynamic. Our noise must go BEYOND passive distractions
(notifications, background apps) to include **active environmental disruptions**
that change the application state the agent is working in.

### THE "MESSY DESK" PRINCIPLE (CRITICAL — calibrate every noise element to this)

Good noise is like working at a messy desk: things are harder to find, the layout
is different from what you expected, but you can still get your work done. Noise
should CHANGE the environment WITHOUT fundamentally BLOCKING the task.

**GOOD noise examples (messy desk):**
- Window pulled 200px off-screen so some buttons are clipped
- A sidebar opens, narrowing the workspace by 30%
- Zoom changes to 120-130% so elements shift position
- Scroll position shifts so the agent must re-orient
- An extra window partially overlaps the workspace
- A toolbar hides, requiring the agent to use menus instead

**BAD noise (too hard — NEVER do these):**
- Switching keyboard layout (invisible input corruption)
- Ctrl+A selecting all text (catastrophic if agent types)
- Switching to fullscreen/Zen mode (all UI vanishes, no recovery cue)
- Changing screen resolution (breaks everything simultaneously)
- Switching color mode to grayscale (disables tools entirely)
- Workspace/desktop switch (all windows vanish)

### TEMPORAL RANDOMNESS (still required)

1. **Temporal randomness**: ALL timed noise MUST use `$((RANDOM % N + M))` to
   randomize delays. NEVER use fixed `sleep N` values.

2. **Ongoing background processes**: Where budget allows, spawn lightweight
   background daemons (via `bash -c "while true; do ... done &"`) for
   periodic notifications, files appearing in ~/Downloads, etc.

3. **Correlated event bursts**: Group related noise events with short random
   gaps (e.g., email notification followed by calendar reminder 5-15s later).

4. **Progressive clutter**: The desktop should get messier over time via
   staggered random intervals.

### VM TOOL AVAILABILITY (USE ONLY THESE — others may not be installed)

The OSWorld VMs run Ubuntu 22.04 with GNOME desktop. These tools are CONFIRMED:
- **wmctrl**: Window management (move, resize, focus, minimize, close, shade)
- **python3 + pyautogui**: Keyboard/mouse simulation (ALWAYS available)
- **notify-send**: Desktop notifications
- **gsettings**: GNOME desktop settings
- **Standard bash/coreutils**: File operations, process management

For keyboard simulation, ALWAYS use pyautogui (guaranteed installed):
  `python3 -c "import pyautogui; pyautogui.hotkey('ctrl', 'p')"`
Do NOT use xdotool (not guaranteed on all VMs).

For window management, use wmctrl (confirmed installed):
  `wmctrl -a 'Window Name'`  (activate/focus window)
  `wmctrl -r 'Window Name' -e 0,X,Y,W,H`  (move/resize)
  `wmctrl -r 'Window Name' -b add,shaded`  (shade/roll-up)
  `wmctrl -c 'Window Name'`  (close window)

### ROBUSTNESS REQUIREMENTS

Every noise command MUST be robust to VM state variations:
- Use `|| true` or `2>/dev/null` for commands that might fail
- Set `DISPLAY=:0` explicitly when using pyautogui in background processes
- Don't assume specific window title strings — use partial matches where possible
- Background processes must be detached with `&` so config execution doesn't hang
- Noise must NOT prevent the target application from launching or functioning

## ADDITIVE-ONLY CONTRACT (CRITICAL — violating this invalidates the output)

The noisy JSON MUST preserve every field and every config step of the input task
JSON verbatim. You may ONLY:
  1. Add new config steps (interleaved between or appended after original steps).
  2. Add a new top-level `noise_meta` field describing what you added.

You MUST NOT:
  - Delete, rename, reorder, or modify any existing field or step.
  - Change `instruction`, `id`, `snapshot`, `source`, `trajectory`, `related_apps`,
    `proxy`, `fixed_ip`, `possibility_of_env_change`, or any other pre-existing field.
  - Change `evaluator.func`, `evaluator.expected`, `evaluator.result`, or
    `evaluator.postconfig`.
  - Touch any file path, URL, window name, or command output string that appears
    anywhere inside the evaluator — these are PROTECTED PATHS and any noise step
    that references them will break evaluation.
  - Introduce credentials, network disruptions, DNS changes, firewall rules, or
    any command that could break VM connectivity.

## INDEPENDENCE

You have no knowledge of any other task or any other agent's output. Do not
reference other tasks, do not assume shared patterns, do not copy from anywhere.
Each analysis is judged on its own merits.

## NOISE BUDGET (STRICTLY ENFORCED)

The user prompt assigns you a difficulty tier and a noise budget. You MUST stay
within that budget:
  - If the budget says "exactly 1 element", add exactly 1 noise step.
  - If the budget says "4-5 elements across 2-3 categories", add 4 or 5 noise
    steps drawn from 2 or 3 distinct categories.
  - Do NOT exceed the maximum. Do NOT go below the minimum.

Rationale: harder tasks receive LESS noise to preserve training signal; easier
tasks receive MORE noise to stress-test robustness.

## OUTPUT FORMAT (REQUIRED)

Your single response MUST contain two sections separated by a delimiter line:

```
<markdown analysis section>

===NOISY_JSON===
<single JSON object: the full noisy task>
```

The markdown section must follow the template given in the user prompt exactly.
The JSON section must be a single valid JSON object with no surrounding text,
code fences, or commentary. Both sections are mandatory."""


NOISE_TAXONOMY_HINTS = """## Noise Category Catalog

There are TWO tiers of noise: **passive background noise** (mild, ignorable) and
**active environmental disruptions** (the agent's workspace actually changes).
Mix BOTH tiers according to the noise budget. Active disruptions are the primary
contribution — passive noise alone is not sufficient.

### TIER 1: PASSIVE BACKGROUND NOISE (available at ALL budget levels)

- **background_apps**: Launch benign Ubuntu apps that clutter the desktop.
    `gedit`, `gnome-calculator`, `nautilus /home/user`, `eog <decoy-image>`,
    `gnome-system-monitor`.
  Config step: `{"type": "launch", "parameters": {"command": ["gedit"]}}`

- **random_notifications**: System notifications via `notify-send` at RANDOM times.
  ALWAYS use `$((RANDOM % N + M))` for delays.
  - Single: `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 120 + 10)) && notify-send 'Slack' 'New message from Priya') &"]}}`
  - Burst: `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 90 + 20)) && notify-send 'Email' 'Meeting in 15 min' && sleep $((RANDOM % 15 + 5)) && notify-send 'Calendar' 'Stand-up starting now') &"]}}`
  - Daemon: `{"type": "execute", "parameters": {"command": ["bash", "-c", "(while true; do sleep $((RANDOM % 60 + 20)); notify-send 'System' 'Software updates available'; done) &"]}}`

- **filesystem_clutter**: Create decoy files in `~/Desktop`, `~/Documents`, or
  `~/Downloads`. MUST NOT collide with evaluator paths.
  - Static: `{"type": "execute", "parameters": {"command": ["bash", "-c", "mkdir -p /home/user/Desktop && touch /home/user/Desktop/report_draft.txt /home/user/Desktop/meeting_notes.txt"]}}`
  - Progressive: `{"type": "execute", "parameters": {"command": ["bash", "-c", "(while true; do sleep $((RANDOM % 90 + 30)); touch /home/user/Downloads/download_$RANDOM.tmp; done) &"]}}`

### TIER 2: ACTIVE ENVIRONMENTAL DISRUPTIONS (the core contribution)

These noise types actively change the application's visual state, requiring the
agent to DETECT, ADAPT, and sometimes RECOVER. They embody the "messy desk"
principle: the environment is harder to work in, but still functional.

**IMPORTANT: Use python3+pyautogui for keyboard simulation (guaranteed on all VMs).
Use wmctrl for window management (confirmed installed).**

- **window_geometry**: Move or resize the target application window so parts are
  off-screen, clipped, or partially covered. This is the GOLD STANDARD of "messy
  desk" noise — the app is still usable but the layout is different.
  Budget: medium and above.
  - Move window 200px off the left edge (left buttons clipped):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 30 + 8)) && wmctrl -r :ACTIVE: -e 0,-200,50,1920,1000) &"]}}`
  - Move window 150px off the top (title bar/menu partially hidden):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 25 + 5)) && wmctrl -r :ACTIVE: -e 0,50,-100,1920,1080) &"]}}`
  - Shrink window to 75% width (narrower workspace):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 20 + 5)) && wmctrl -r :ACTIVE: -e 0,100,50,1440,900) &"]}}`
  - Move background app to partially overlap the target:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 20 + 5)) && wmctrl -r 'gedit' -e 0,600,200,700,500) &"]}}`

- **window_occlusion**: Launch a NEW window that partially or fully covers the
  target workspace. The agent must close, minimize, or work around it.
  Budget: easy and above.
  - System Settings covers workspace:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 60 + 15)) && gnome-control-center) &"]}}`
  - File manager opens over terminal:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 40 + 10)) && nautilus /home/user/Desktop) &"]}}`
  - Second terminal (offset, not maximized — agent can distinguish them):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 50 + 20)) && gnome-terminal --geometry=80x24+100+100 2>/dev/null) &"]}}`
  - Always-on-top calculator blocking part of workspace (very_easy only):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(gnome-calculator & sleep 3 && wmctrl -r 'Calculator' -b add,above && wmctrl -r 'Calculator' -e 0,400,300,300,200) &"]}}`

- **panel_toggle**: Toggle a sidebar, toolbar, or panel in the target app using
  pyautogui keyboard shortcuts. The workspace layout changes but is still usable.
  Budget: medium and above.
  - VS Code: toggle Explorer sidebar off:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 35 + 10)) && wmctrl -a 'Visual Studio Code' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'b')\") &"]}}`
  - VS Code: switch bottom panel from Terminal to Output:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 35 + 10)) && wmctrl -a 'Visual Studio Code' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'shift', 'u')\") &"]}}`
  - Writer: open Navigator sidebar (narrows editing area ~30%):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 35 + 10)) && wmctrl -a 'LibreOffice Writer' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.press('f5')\") &"]}}`
  - Impress: close slide panel:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 35 + 10)) && wmctrl -a 'LibreOffice Impress' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.press('tab')\") &"]}}`
  - GIMP: reposition Layers dialog to unexpected location (NOT close it):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 30 + 10)) && wmctrl -r 'Layers' -e 0,50,600,250,300 2>/dev/null) &"]}}`

- **view_mode_change**: Change the app's view mode or zoom level moderately.
  The app is still usable but looks different — elements shift position.
  Budget: medium and above. Keep changes MODERATE (never extreme).
  - Chrome: zoom to ~125% (3 presses of Ctrl+Plus):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 30 + 10)) && wmctrl -a 'Google Chrome' && DISPLAY=:0 python3 -c \"import pyautogui, time; [pyautogui.hotkey('ctrl', 'plus') or time.sleep(0.1) for _ in range(3)]\") &"]}}`
  - Chrome: open DevTools panel (shrinks page ~40% but still usable):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 40 + 15)) && wmctrl -a 'Google Chrome' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.press('f12')\") &"]}}`
  - Writer: enable Track Changes (visual markup, NOT for content-eval tasks):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 40 + 15)) && wmctrl -a 'LibreOffice Writer' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'shift', 'c')\") &"]}}`
  - Calc: switch to Page Break Preview:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 30 + 10)) && wmctrl -a 'LibreOffice Calc' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('alt', 'v') ; import time; time.sleep(0.3); pyautogui.press('b')\") &"]}}`
  - VS Code: split editor into two panes:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 30 + 10)) && wmctrl -a 'Visual Studio Code' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'backslash')\") &"]}}`

- **scroll_displacement**: Shift the scroll/cursor position so the agent must
  re-orient. Keep displacement MODERATE (partial, not total context loss).
  Budget: medium and above.
  - Chrome: new blank tab steals focus from working tab:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 45 + 15)) && wmctrl -a 'Google Chrome' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 't')\") &"]}}`
  - Chrome: focus jumps to address bar (keyboard input goes wrong place):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 40 + 15)) && wmctrl -a 'Google Chrome' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'l')\") &"]}}`
  - Calc: active sheet switches to next tab:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 35 + 15)) && wmctrl -a 'LibreOffice Calc' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'pagedown')\") &"]}}`
  - Writer: cursor jumps to end of document:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 40 + 15)) && wmctrl -a 'LibreOffice Writer' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'End')\") &"]}}`

- **dialog_popup**: Open a dialog (Find/Replace, Command Palette, etc.) that
  captures keyboard focus. Agent must dismiss it (usually Escape). Keep to ONE
  dialog per task — multiple stacked modals is too hard.
  Budget: easy and above.
  - Chrome: Find bar opens with search text:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 40 + 15)) && wmctrl -a 'Google Chrome' && DISPLAY=:0 python3 -c \"import pyautogui, time; pyautogui.hotkey('ctrl', 'f'); time.sleep(0.3); pyautogui.typewrite('settings', interval=0.05)\") &"]}}`
  - VS Code: Command Palette opens:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 30 + 10)) && wmctrl -a 'Visual Studio Code' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'shift', 'p')\") &"]}}`
  - Writer/Calc: Find & Replace dialog:
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 40 + 15)) && wmctrl -a 'LibreOffice' && DISPLAY=:0 python3 -c \"import pyautogui; pyautogui.hotkey('ctrl', 'h')\") &"]}}`
  - Impress: Slide Properties dialog (via menu):
    `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 40 + 15)) && wmctrl -a 'LibreOffice Impress' && DISPLAY=:0 python3 -c \"import pyautogui, time; pyautogui.hotkey('alt', 's'); time.sleep(0.3); pyautogui.press('p')\") &"]}}`

- **focus_stealing**: A background app grabs focus at a random time, forcing
  the agent to re-focus on the target window. Pair with a background_app launch.
  Budget: easy and above.
  - `{"type": "execute", "parameters": {"command": ["bash", "-c", "(sleep $((RANDOM % 90 + 30)) && wmctrl -a 'gedit') &"]}}`
  Best paired with launching gedit first via background_apps.

### TIER-TO-CATEGORY MAPPING (STRICTLY ENFORCED)

| Tier      | Passive categories        | Active categories allowed                           |
|-----------|---------------------------|-----------------------------------------------------|
| very_hard | 1 notification only       | NONE (budget too small)                             |
| hard      | notifications, 1 bg app   | At most 1 mild: window_geometry only                |
| medium    | notifications, bg apps    | 1-2 from: window_geometry, panel_toggle, view_mode  |
| easy      | all passive               | 2-3 from: + window_occlusion, scroll_displacement,  |
|           |                           |   dialog_popup, focus_stealing                      |
| very_easy | all passive               | 3-5 from ALL active categories                      |

### Domain-specific hints (combine with categories above)

- **chrome**: DevTools (F12), Side Panel, Find bar with text, new tab, zoom, address bar focus
- **libreoffice_writer**: Navigator sidebar (F5), Track Changes, scroll displacement, Find/Replace
- **libreoffice_calc**: Sheet tab switch, Page Break Preview, frozen panes, cell jump, formula bar
- **libreoffice_impress**: Slide panel toggle, Outline view (mild), drawing tool change, Slide Sorter (very_easy only)
- **vs_code**: Terminal/Output panel swap, Explorer toggle, editor split, Command Palette, Source Control sidebar
- **gimp**: Reposition (not close!) floating dialogs, moderate zoom change, tool switch (use with caution)
- **vlc**: Advanced Controls toolbar toggle, playback speed (0.75-0.8x, not extreme)
- **thunderbird**: Reading pane layout change, folder pane toggle (F9), Account Settings tab
- **os/terminal**: File manager overlap, second terminal (offset), window shade (title bar only)
- **multi_apps**: Cross-app notification bursts, layer noise from each sub-domain conservatively

## Key integrity rules (applies to ALL categories)
1. Every noise step must be a valid OSWorld config entry: `{"type": "launch", ...}`,
   `{"type": "execute", ...}`, etc.
2. Never overwrite files or directories referenced by the evaluator.
3. Never modify original `chrome_open_tabs` in place — add a NEW step if needed.
4. Preserving the original step byte-identical is MANDATORY.
5. Every background process must use `&` to avoid hanging config execution.
6. Every pyautogui call must be preceded by `DISPLAY=:0` in background processes.
7. Use `2>/dev/null` or `|| true` for commands that might fail on some VM configs."""


MARKDOWN_TEMPLATE = """# Noise Analysis: {task_id}

## Task Context
- **Domain**: {domain}
- **Instruction**: {instruction}
- **MCTS Success Rate**: {success_rate:.4f} ({successful_trajectories}/{total_runs} rollouts)
- **Difficulty Tier**: {tier}
- **Noise Budget**: {budget_description}

## Original Config Summary
<1-3 sentences describing what the clean config does, e.g. "Launches Chrome, opens
the drugs.com tab, activates the window, and maximizes it via pyautogui.">

## Evaluator Analysis
- **Function(s)**: <list evaluator.func values>
- **Protected paths / URLs / windows**: <exhaustive list of every file path, URL,
  or window name referenced inside evaluator.result, evaluator.expected, or
  evaluator.postconfig — noise must NOT touch these>
- **Failure modes to avoid**: <specific things noise must not do for this task>

## Proposed Noise Additions

### 1. <category>: <short title>
- **Description**: <1-2 sentences>
- **Config step (JSON)**:
  ```json
  {{"type": "...", "parameters": {{...}}}}
  ```
- **Where to insert**: <before/after step N of original config, or appended at end>
- **Rationale**: <why this noise is realistic for this task's domain>
- **Evaluator interference risk**: <low | medium | high> — <reasoning>

### 2. <category>: <short title>
...

(Repeat until budget exhausted. Number of entries MUST match noise_element_count
in the JSON output.)

## Temporal Randomness Strategy
Explain how your noise additions create a LIVING environment, not a static snapshot:
- **Which steps use randomized timing?** (list step numbers and their `$((RANDOM % N + M))` ranges)
- **Are there any ongoing background daemons?** (periodic notifications, progressive clutter)
- **Are there correlated event bursts?** (e.g., email + calendar 10s apart)
- **Does the environment get progressively messier over time?** (staggered launches, accumulating files)
- **Any focus-stealing events?** (if tier permits)

If the noise budget is very small (very_hard/hard), a single randomized notification
is sufficient — explain why you chose that specific randomization range.

## Safety Checklist
- [ ] All original config steps preserved in same relative order
- [ ] All top-level fields preserved byte-identical (id, snapshot, instruction, source, trajectory, related_apps, evaluator, proxy, fixed_ip, possibility_of_env_change)
- [ ] `instruction` unchanged
- [ ] `evaluator.func` unchanged
- [ ] `evaluator.expected` unchanged
- [ ] No noise step touches any protected path listed above
- [ ] No credentials, network disruption, or unsafe commands
- [ ] Noise element count within budget
- [ ] All timed noise steps use randomized delays (`$((RANDOM % N + M))`), NOT fixed `sleep` values

## Notes for Human Reviewer
<any judgment calls, edge cases, or uncertainties>"""


NOISY_JSON_SPEC = """## Noisy JSON Specification (second half of response, after the delimiter)

Emit a single JSON object that is the input task JSON VERBATIM plus:

1. **Additional config steps** interleaved or appended into the `config` array.
   Original steps must appear in their original relative order (you may insert
   noise steps between them or after them, but never reorder or remove them).

2. **A new top-level `noise_meta` field** with this exact schema:
   ```json
   {
     "noise_meta": {
       "generated_by": "noise_generation/generate_noise.py",
       "model": "<model name from environment>",
       "tier": "<very_hard|hard|medium|easy|very_easy>",
       "success_rate_used": <float>,
       "categories_applied": ["<category1>", "<category2>", ...],
       "noise_element_count": <int — must equal len(noisy.config) - len(clean.config)>,
       "added_step_indices": [<0-based index in the noisy config of each added step>]
     }
   }
   ```

Every other field (`id`, `snapshot`, `instruction`, `source`, `config[original steps]`,
`trajectory`, `related_apps`, `evaluator`, `proxy`, `fixed_ip`,
`possibility_of_env_change`, and any others present) MUST be byte-identical to
the input.

Do NOT wrap the JSON in markdown code fences. Do NOT add commentary after it.
Emit a single raw JSON object immediately after the delimiter line."""


def build_user_prompt(
    task_id: str,
    domain: str,
    task_json: Dict[str, Any],
    success_rate: float,
    total_runs: int,
    successful_trajectories: int,
    tier: str,
    budget_description: str,
) -> str:
    """Construct the per-task user prompt."""
    instruction = task_json.get("instruction", "<no instruction field>")
    task_json_pretty = json.dumps(task_json, indent=2, ensure_ascii=False)

    markdown_template_filled = MARKDOWN_TEMPLATE.format(
        task_id=task_id,
        domain=domain,
        instruction=instruction,
        success_rate=success_rate,
        successful_trajectories=successful_trajectories,
        total_runs=total_runs,
        tier=tier,
        budget_description=budget_description,
    )

    parts = [
        f"# Task to analyze\n",
        f"**Task ID**: `{task_id}`",
        f"**Domain**: `{domain}`",
        f"**Instruction**: {instruction}",
        f"",
        f"## MCTS rollout statistics (from checkpoints/mcts_trajectories_v2)",
        f"- Success rate: **{success_rate:.4f}**",
        f"- Successful trajectories: {successful_trajectories}",
        f"- Total runs: {total_runs}",
        f"",
        f"## Assigned difficulty tier: **{tier}**",
        f"",
        f"## Assigned noise budget",
        f"{budget_description}",
        f"",
        f"## Full clean task JSON (preserve every field byte-identical)",
        f"```json",
        task_json_pretty,
        f"```",
        f"",
        NOISE_TAXONOMY_HINTS,
        f"",
        NOISY_JSON_SPEC,
        f"",
        f"## Required output",
        f"",
        f"Produce your response in this exact structure:",
        f"",
        f"1. First, the markdown analysis matching this template EXACTLY (you may extend Proposed Noise Additions with more numbered entries, but the overall section structure is fixed):",
        f"",
        f"```markdown",
        markdown_template_filled,
        f"```",
        f"",
        f"2. Then, on its own line, the literal delimiter:",
        f"",
        f"    {OUTPUT_DELIMITER}",
        f"",
        f"3. Then, immediately after the delimiter, the single noisy task JSON object per the specification above. No code fences, no commentary.",
        f"",
        f"Remember: the noisy JSON must be STRICTLY ADDITIVE. Every original field and every original config step must appear verbatim. You may only add new config steps and a new `noise_meta` field.",
    ]

    return "\n".join(parts)
