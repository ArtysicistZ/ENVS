# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
PPO config
"""

import os
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from typing import Optional, Tuple

from ..workers.config import WorkerConfig


def recursive_post_init(dataclass_obj):
    if hasattr(dataclass_obj, "post_init"):
        dataclass_obj.post_init()

    for attr in fields(dataclass_obj):
        if is_dataclass(getattr(dataclass_obj, attr.name)):
            recursive_post_init(getattr(dataclass_obj, attr.name))


@dataclass
class DataConfig:
    train_files: str = ""
    val_files: str = ""
    prompt_key: str = "prompt"
    answer_key: str = "answer"
    image_key: str = "images"
    max_prompt_length: int = 512
    max_response_length: int = 512
    rollout_batch_size: int = 512
    val_batch_size: int = -1
    val_n_repeats: int = 1  # repeat each val task N times (for n=8 filtering runs)
    format_prompt: Optional[str] = None
    shuffle: bool = True
    seed: int = 1
    max_pixels: int = 4194304
    min_pixels: int = 262144


@dataclass
class AlgorithmConfig:
    gamma: float = 1.0
    lam: float = 1.0
    adv_estimator: str = "grpo"
    disable_kl: bool = False
    use_kl_loss: bool = False
    kl_penalty: str = "kl"
    kl_coef: float = 1e-3
    kl_type: str = "fixed"
    kl_horizon: float = 0.0
    kl_target: float = 0.0
    enable_replay: bool = False

    # Opt-in noise system (see docs/noise_generating/RESEARCH_FRAMING.md).
    # Inert when enable_noise=False — clean training/eval is byte-identical
    # to pre-feature behavior. All fields below are only consulted when
    # enable_noise=True.
    enable_noise: bool = False
    noise_mode: str = "none"  # none | task_noise_meta | runtime_library
    # Static firing probability (used when noise_use_curriculum=False); also
    # serves as p_init when the curriculum is enabled.
    noise_probability: float = 0.05
    noise_probability_min: float = 0.0
    noise_probability_max: float = 0.30
    # Capability-adaptive curriculum: EMA-based tier + p drift per task.
    noise_use_curriculum: bool = False
    noise_target_sr: float = 0.5
    noise_tau_up: float = 0.6
    noise_tau_down: float = 0.15
    noise_k_up: int = 3
    noise_ema_alpha: float = 0.3
    noise_lr: float = 0.05
    noise_initial_tier: int = 1
    noise_tier_min: int = 0
    noise_tier_max: int = 5
    # Eval-time flag: sampler draws from held-out OOD template catalog.
    noise_use_heldout: bool = False


@dataclass
class TrainerConfig:
    total_episodes: int = 10
    max_steps: Optional[int] = None
    project_name: str = "easy_r1"
    experiment_name: str = "demo"
    wandb_entity: Optional[str] = None  # e.g. "hanszhu05" or team name; runs go to this account when set
    logger: Tuple[str] = ("console", "wandb")
    nnodes: int = 1
    n_gpus_per_node: int = 8
    critic_warmup: int = 0
    val_freq: int = -1
    val_before_train: bool = True
    val_only: bool = False
    val_generations_to_log: int = 0
    save_freq: int = -1
    save_limit: int = -1
    save_checkpoint_path: Optional[str] = None
    load_checkpoint_path: Optional[str] = None
    replay_data_path: Optional[str] = None  # path to pre-collected replay trajectories (.pt)
    save_trajectories: bool = False  # save compact episode trajectories to JSONL for SFT

    def post_init(self):
        if self.save_checkpoint_path is None:
            self.save_checkpoint_path = os.path.join("checkpoints", self.project_name, self.experiment_name)

@dataclass
class EnvConfig:
    num_envs: int = 32
    max_steps: int = 15
    screen_size: Tuple[int, int] = (1920, 1080)
    # Remote env (Mac/AWS): when set, EnvWorkers talk to this URL instead of local Docker.
    remote_server_url: Optional[str] = None
    remote_server_urls: Optional[list[str]] = None
    remote_server_env_counts: Optional[list[int]] = None  # VMs per server; if set, distribute workers proportionally instead of round-robin

@dataclass
class PPOConfig:
    data: DataConfig = field(default_factory=DataConfig)
    worker: WorkerConfig = field(default_factory=WorkerConfig)
    algorithm: AlgorithmConfig = field(default_factory=AlgorithmConfig)
    trainer: TrainerConfig = field(default_factory=TrainerConfig)
    env: EnvConfig = field(default_factory=EnvConfig)

    def post_init(self):
        self.worker.rollout.prompt_length = self.data.max_prompt_length
        self.worker.rollout.response_length = self.data.max_response_length
        self.worker.actor.disable_kl = self.algorithm.disable_kl
        self.worker.actor.use_kl_loss = self.algorithm.use_kl_loss
        self.worker.actor.kl_penalty = self.algorithm.kl_penalty
        self.worker.actor.kl_coef = self.algorithm.kl_coef

    def deep_post_init(self):
        recursive_post_init(self)

    def to_dict(self):
        return asdict(self)
